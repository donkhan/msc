import sys


def print_line():
    print("-----------------------------------------------------")


def print_version():
   print(sys.version)

