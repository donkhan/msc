from Process import *


class Idle(Process):
    def __init__(self,tokens):
        self.pid = "IDLE"
