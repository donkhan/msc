This Program will simulate round robin scheduling algorithm implemented in Operating Systems. Written in python with
matplotlib as graphical tool